#define DELAY_TIME 500

const int led = 13;

void toggleDelay(int state, int time_ms);
