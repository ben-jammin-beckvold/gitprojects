#Ben Beckvold HW6 Part 2
#the first function does the line, word, and character count
#the second was an attempt at using list comprehension to count the digits and white space - it does not work
#the 3rd function does count the digits and whitespace correctly althought not using list comprehension.
#all 3 are printed if you run the program

def wordCount(str):
    return [len(str.split("\n")), len(str.split()), len(list(str))]

def testFreqCount(str):
    return [str.count(str[i]) for i in range(len(str)) if str[i]>='0' and str[i]<='9' ]

def workingFreqCount(str):
    return [str.count("0"), str.count("1"), str.count("2"), 
            str.count("3"), str.count("4"), str.count("5"), 
            str.count("6"), str.count("7"), str.count("8"), 
            str.count("9"), str.count(" ")+str.count("\n")+str.count("\t")]

testString = """The quick brown fox jumped over the lazy dog
this is the point
does it record 5 lines and some numbers?
24 or 29
Lets find out."""

print "Test String\n"
print testString

print "Line --- Word --- Character   Count"
print wordCount(testString)

print "Digit[0-9] --- White Space --- Other   Count "
print testFreqCount(testString)
        
print "Digit[0-9] --- White Space --- Other   Count "
print workingFreqCount(testString)
